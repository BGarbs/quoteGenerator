$(document).ready(function(){
  $("#getMessage").on("click", function() {
    
  });
});